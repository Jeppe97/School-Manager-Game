package real;

import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;

public class Player extends GameObject{

	public Player(int x, int y, ID id) {
		super(x, y, id);
		velX = 1;
	}

	public void tick() {
		x += velX;
		y += velY;
		
		x = Game.clamp(x, 480, 1440-32);
		y = Game.clamp(y, 60, Game.HEIGHT-150);
	}

	public void render(Graphics g) throws IOException {
		g.setColor(Color.white);
		g.fillRect(x, y, 32, 32);
	}

}
