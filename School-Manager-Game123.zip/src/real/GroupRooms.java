package real;

import java.awt.Graphics;
import java.io.IOException;

public class GroupRooms extends GameObject{

	public GroupRooms(int x, int y, ID id) {
		super(x, y, id);

		groupRooms = 500;
		
	}

	public void tick() {
		groupRoomString = Integer.toString(groupRooms);
		
	}

	public void render(Graphics g) throws IOException {
		// TODO Auto-generated method stub
		
	}

}
