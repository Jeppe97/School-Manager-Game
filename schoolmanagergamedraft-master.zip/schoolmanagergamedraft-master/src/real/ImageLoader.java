package real;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageLoader {

	
	private static BufferedImage multisalen;
	private static BufferedImage canteen;
	private static BufferedImage library;
	private static BufferedImage parkinglot;
	private static BufferedImage office;
	//Not used yet private static BufferedImage toprow;
	//Not used yet private static BufferedImage bottomrow;
	private static BufferedImage row;
	private static BufferedImage button1;
	private static BufferedImage desk;
	private static BufferedImage canteenBtn1;
	private static BufferedImage canteenBtn2;
	private static BufferedImage canteenBtn3;
	// Not used yet private static BufferedImage imgplaceholder;
	
	private ImageLoader(){
		throw new IllegalStateException("Utility Class");
	}
	
	public static void load() {
		
		try {
			multisalen = ImageIO.read(new File("res/multisalen.jpg"));
			canteen = ImageIO.read(new File("res/canteen.jpg"));
			library = ImageIO.read(new File("res/library.jpg"));
			parkinglot = ImageIO.read(new File("res/parkinglot.jpg"));
			office = ImageIO.read(new File("res/office.jpg"));
			row = ImageIO.read(new File("res/grayField2.png"));
			desk = ImageIO.read(new File("res/desk.png"));
			button1 = ImageIO.read(new File("res/btn.png"));
			canteenBtn1 = ImageIO.read(new File("res/canteenBtn1.png"));
			canteenBtn2 = ImageIO.read(new File("res/canteenBtn2.png"));
			canteenBtn3 = ImageIO.read(new File("res/canteenBtn3.png"));
		
		
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static BufferedImage getImg(String name) {
	
		if(name.equals("multisalen"))
			return multisalen;
		else if(name.equals("canteen"))
			return canteen;
		else if(name.equals("library"))
			return library;
		else if(name.equals("parkinglot"))
			return parkinglot;
		else if(name.equals("office"))
			return office;
		else if(name.equals("row"))
			return row;
		else if (name.equals("desk"))
			return desk;
		else if(name.equals("button"))
			return button1;
		else if (name.equals("canteenbutton1"))
			return canteenBtn1;
		else if (name.equals("canteenbutton2"))
			return canteenBtn2;
		else if (name.equals("canteenbutton3"))
			return canteenBtn3;
		else
			return null;	
	}
	
	
	
}
