package real;

public enum ID {
	
	STUDENTS(),
	POPUP(),
	TOPROW(),
	MONEY(),
	MOOD(),
	PARKINGS(),
	GROUPROOM(),
	PLAYER(),
	ENEMY(),
	TABLES();
}
