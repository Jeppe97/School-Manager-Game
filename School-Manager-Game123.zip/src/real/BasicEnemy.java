package real;

import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;

public class BasicEnemy extends GameObject {

	public BasicEnemy(int x, int y, ID id) {
		super(x, y, id);
		// TODO Auto-generated constructor stub
	}

	public void tick() {
		// TODO Auto-generated method stub
		
	}

	public void render(Graphics g) throws IOException {
		g.setColor(Color.red);
		g.fillRect(x, y, 16, 16);
	}

}
