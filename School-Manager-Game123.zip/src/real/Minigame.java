package real;

import java.awt.Color;
import java.awt.Graphics;

public class Minigame {
	
	Handler handler;
	int counter = 400;
	boolean playeradded = false;
	
	public Minigame(Handler handler) {
		this.handler = handler;
	
	}
	
	
	public void tick() {
		
		//if(counter == 400)
			//Game.gameState = Game.STATE.OFFICE;
		//counter--;

		
	}
	public void render(Graphics g) {
		g.setColor(Color.WHITE);
		g.drawRect(480, 60, 960, Game.HEIGHT-182);
		
		if(!playeradded) {
			handler.addObject(new Player(960, Game.HEIGHT-182, ID.PLAYER));
			playeradded = true;
		}
		
		
	}
	
}
