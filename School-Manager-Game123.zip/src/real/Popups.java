package real;


import java.awt.Graphics;

public class Popups {
	
	private Game game;
	
	public Popups(Game game) {
		this.game = game;
	}
	
	
	
	public void render(Graphics g) {
		
		if(true) {
			
		}
		
		
	}
	
	
	
}